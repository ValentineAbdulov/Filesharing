from flask_wtf import FlaskForm
from wtforms import PasswordField, StringField, TextAreaField, IntegerField, SelectField, FileField
from wtforms.validators import DataRequired, Length, EqualTo


class SignupForm(FlaskForm):
    username = StringField(
        "Username: ",
        validators=[
            DataRequired(),
            Length(
                6,
                32,
                message="Ім'я користувача має бути завдовжки від 6 до 32 символів",
            ),
        ],
    )
    password = PasswordField(
        "Password: ",
        validators=[
            DataRequired(),
            Length(8, 32, message="Пароль має бути завдовжки від 8 до 32 символів"),
        ],
    )
    password_rep = PasswordField("Repeat password: ", validators=[EqualTo("password")])


class SigninForm(FlaskForm):
    username = StringField(
        "Username: ",
        validators=[
            DataRequired(),
            Length(
                6,
                32,
                message="Ім'я користувача має бути завдовжки від 6 до 32 символів",
            ),
        ],
    )
    password = PasswordField(
        "Password: ",
        validators=[
            DataRequired(),
            Length(8, 32, message="Пароль має бути завдовжки від 8 до 32 символів"),
        ],
    )

class FileForm(FlaskForm):
    file = FileField(
        'File',
        validators=[DataRequired(),
        ],
    )
    expiring_choice = SelectField(
        "Expiring: ",
        choices=[
            (60*60*24*7, '7 days'),
            (60*60*24*14, "14 days"),
            ('one_time', "1 downloading(will be deleted after only 1 downloading)"),
        ],
        validators=[DataRequired()],
    )

class DownloadForm(FlaskForm):
    link = StringField(
        'File link code: ',
        validators=[DataRequired()],
    )